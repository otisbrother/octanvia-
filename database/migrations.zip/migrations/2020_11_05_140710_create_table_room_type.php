<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableRoomType extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('table_room_type', function (Blueprint $table) {
            $table->bigIncrements('roomType_id');
            $table->string('name')->collation('utf8mb4_unicode_ci')->nullable();//loại nhà trọ
            $table->dateTime('create_date')->default(null);
            $table->string('create_by')->default(null);
            $table->string('update_by', 200)->default(null);
            $table->integer('status')->default(1);//trạng thái
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('table_room_type');
    }
}
