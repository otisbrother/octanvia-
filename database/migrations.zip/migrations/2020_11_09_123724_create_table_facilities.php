<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableFacilities extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('table_facilities', function (Blueprint $table) {
            $table->bigIncrements('facilities_id');
            $table->string('title', 200)->collation('utf8mb4_unicode_ci')->nullable();//tiêu đề
            $table->integer('parent_id')->default(0);
            $table->integer('require')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('table_facilities');
    }
}
