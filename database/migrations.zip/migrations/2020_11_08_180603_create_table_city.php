<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableCity extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('table_city', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('name',200)->collation('utf8mb4_unicode_ci')->nullable();
            $table->date('create_date')->default(null);
            $table->string('create_by',200)->default(null);
            $table->date('update_date')->default(null);
            $table->string('update_by',200)->default(null);
            $table->integer('status')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('table_city');
    }
}
